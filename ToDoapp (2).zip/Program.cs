var builder = WebApplication.CreateBuilder(args);

// Adaugă suport pentru MVC (Controllers + Views)
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Configurează pipeline-ul HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

//app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

// RUTA IMPLICITĂ — controllerul de start e TaskController
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Task}/{action=Index}/{id?}");

app.Run();
