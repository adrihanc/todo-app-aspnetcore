using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using TodoApp.Models;

namespace TodoApp.Controllers
{
    public class TaskController : Controller
    {
        // Corect: listă generică de TaskItem
        private static List<TaskItem> tasks = new List<TaskItem>();

        // GET: /Task/
        public IActionResult Index()
        {
            return View(tasks);
        }

        // POST: /Task/Add
        [HttpPost]
        public IActionResult Add(string title)
        {
            if (!string.IsNullOrWhiteSpace(title))
            {
                var newTask = new TaskItem
                {
                    Id = tasks.Count + 1,
                    Title = title,
                    IsDone = false
                };
                tasks.Add(newTask);
            }
            return RedirectToAction("Index");
        }

        // POST: /Task/ToggleDone
        [HttpPost]
        public IActionResult ToggleDone(int id)
        {
            var task = tasks.Find(t => t.Id == id);
            if (task != null)
            {
                task.IsDone = !task.IsDone;
            }
            return RedirectToAction("Index");
        }

        // GET: /Task/Test
        [HttpGet]
        public IActionResult Test()
        {
            return Content("Controllerul Task e OK");
        }
    }
}
